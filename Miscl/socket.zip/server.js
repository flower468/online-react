var express = require("express");
var app = express();
var server = require("http").createServer(app);
var io = require("socket.io").listen(server);
	app.use(express.static(__dirname));

// var users = [];
var connections = [];
server.listen(process.env.PORT || 3000);
console.log("server is now running on port 3000");

app.get("/", function(req, res){
	res.sendFile(__dirname+"/index.html")
});

io.sockets.on("connection", function(socket){
	// handling creating a new socket connection
	connections.push(socket);
	// console.log("Connected: %s sockets connected",connections.length);
	console.log("Connected: "+connections.length+" sockets connected");
	
	// handling disconnection of a socket connection
	socket.on("disconnect", function(socket){
	connections.splice(connections.indexOf(socket), 1);
	// console.log("Disconnected: %s sockets connected",connections.length);
	console.log("Disconnected: "+connections.length+" sockets connected");
	}); 
	
	socket.on("message", function(data){
		console.log(data)
	})
	
	setInterval(function(){
		socket.emit("toclient", Math.random() )
	},2000)
	
});



