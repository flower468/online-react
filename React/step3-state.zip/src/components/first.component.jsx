import { Component }  from "react";

/*
settings = {firstVal : true, secondVal : true}
*/
export class FirstComp extends Component{
   
    constructor(){
        super();
        this.state = {
            title : 'Hero app',
            power : 1,
            settings : {firstVal : true, secondVal : true}
        };
        this.state.power = 5;
        // this.increasePower = this.increasePower.bind(this);
    }
    increasePower(){
        console.log(" Increase Power was called ");
        this.setState({
            power : this.state.power+1,
            settings : { firstVal : true, secondVal : false }
        });
    }
    render(){
    return <div>
        <h1>Title : { this.state.title }</h1>
        <h1>Power : { this.state.power }</h1>
        <h1> { this.state.settings.firstVal+'' } { this.state.settings.secondVal+'' } </h1>
        <button onClick={ this.increasePower.bind(this) }>Increase Power </button>
    </div>
    }

}

// <button onClick={ () => this.increasePower() }>Increase Power </button>