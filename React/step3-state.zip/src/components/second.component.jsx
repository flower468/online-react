const { Component } = require("react");

class SecondComp extends Component{
    constructor(){
        super();
        this.state = {
            power : 0
        }
    }

    increasePower = () => {
        // this.setState({ power : this.state.power+1 });
        // console.log(this.state.power);

        /*
        this.setState({ power : this.state.power+1 }, function(){
            console.log(this.state.power);
        });
       */
      this.setState(function(prevState, props){
        //  console.log(arguments.length, arguments[0], arguments[1]);
        return {
            power : prevState.power+1
        }
    }, function(){
        console.log(this.state.power)
      })
    }

    render(){
        return<div>
            <h1>Hello from Second Component Power is : { this.state.power }</h1>
            <button onClick={ this.increasePower } >Increase Power </button>
            </div>
    }
}

export default SecondComp;
