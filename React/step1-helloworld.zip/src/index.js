import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Hero extends Component{

    render(){
    return <p>I got { this.props.title } version is { this.props.version } {this.props.children} </p>
    }
  }

class MainApp extends Component{

  render(){
    return <div>
            <h1>Welcome to your life</h1>
            <Hero title="Hello Hero App" version="150" > 
              <ul>
                <li>List item 1</li>
                <li>List item 2</li>
                <li>List item 2</li>
              </ul>
            </Hero>
          </div>
    
  }
}

ReactDOM.render(<MainApp/>,document.querySelector('#root'));
