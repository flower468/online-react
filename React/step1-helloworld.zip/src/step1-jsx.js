import React, { Component } from 'react';
import ReactDOM from 'react-dom';
/*
you can not user uppercase tag names
className in place of class
htmlFor in place of for
event names are camel cased
always close the inline tags
binding with {}
*/


class MainApp extends Component{
  constructor(props){
    super(props)
    this.btntext = "Click Me";
  }
  render(){
    return <React.Fragment>
             <header className="box"> welcome to your life again </header>
              <main>
                <article>
                      place holder text comes here 
                </article>
                <article>
                      place holder text comes here 
                      <button>{ this.btntext }</button>
                </article>
                
              </main>
            <footer> copyrights reserved to you company </footer>
           </React.Fragment>
  }
}
// React.createElement("h1", null, 
//  React.createElement("header",null, ""),
// )

ReactDOM.render(<MainApp/>,document.querySelector('#root'));
