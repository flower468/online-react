let express = require('express');
let app = express();
    app.use(express.static(__dirname));
app.get('/', function(req, res){
    res.sendFile(__dirname+"/step1-destructuring.html");
})
app.listen(3000);
console.log("the server is now live on localhost:3000")