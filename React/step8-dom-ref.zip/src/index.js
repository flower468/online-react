import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  constructor(){
    super();
    this.headingRef = React.createRef();
    this.nameInputRef = React.createRef();
    this.powerRef = React.createRef();
  }

  addPower = ()=>{
    this.powerRef.current.increasePower();
  }
  removePower = ()=>{
    this.powerRef.current.decreasePower();
  }

  render(){
    return <div>
      <h1 ref={ this.headingRef }> Welcome to your life </h1>
      <input ref={ this.nameInputRef } />
      <button onClick={ this.addPower }>Increase</button>
      <button onClick={ this.removePower }>Decrease</button>
      <PowerDisplay ref={ this.powerRef }/>
    </div>
  }

  componentDidMount(){
    setTimeout(() => {
      console.log( this.headingRef.current.innerHTML );
      this.nameInputRef.current.value = "I was assigned a value";
    }, 4000);
  }
}

class PowerDisplay extends Component{
  constructor(){
    super();
    this.state = {
        power : 0
    }
  }
  increasePower = ()=>{
    this.setState({
      power : this.state.power+1
    })
  }
  decreasePower = ()=>{
    this.setState({
      power : this.state.power-1
    })
  }
  render(){
    return <div>
      <h1> Power is : { this.state.power } </h1>
    </div>
  }
}



ReactDOM.render(<MainApp/>,
  document.getElementById('root')
);
