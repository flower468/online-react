import { Component } from "react";
import PropTypes from "prop-types";

export class Hero extends Component{
    // static defaultProps = {
    //     title : "Heroes App"
    // }
    render(){
    return <div>
        <h1> { this.props.title } Version  : { this.props.ver } </h1>
        <ol>{
            this.props.hlist.map((val, idx) => <li key={ idx }>{ val }</li>)
        }</ol>
    </div>
    }
}
Hero.defaultProps = {
         title : "Comic Heroes App"
}
Hero.propTypes = {
    ver : PropTypes.number.isRequired,
    hlist : PropTypes.array,
    title : PropTypes.string
}