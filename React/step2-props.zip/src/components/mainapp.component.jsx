import { Component } from "react";
import { Hero } from "./hero.component"


let justiceLegue = ['Batman', 'Superman', 'Aquaman', 'Wonder Women', 'Cat Women', 'Flash', 'Cyborg', 'Martian Manhunter'];
let avengers = ['Ironman', 'Spiderman', 'Thor', 'Blak Panther', 'Black Widow', 'Scarlet Witch', 'Hulk', 'Captain America', 'Captain Marvel'];
let list1 = "Justice Legue";
let list2 = "Avengers";
let version = 101;

export class MainApp extends Component{

  render(){
      return <div>
              <h1>Welcome to your life</h1>
              <Hero ver={ version } title={ list1 } hlist={ justiceLegue }></Hero>
              <hr/>
              <Hero ver={ version } title={ list2 } hlist={ avengers }></Hero>
            </div>
      
    }
  }