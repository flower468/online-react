import React from 'react';
import ReactDOM from 'react-dom';
import { MainApp } from './components/mainapp.component';


ReactDOM.render(<MainApp/>,document.querySelector('#root'));