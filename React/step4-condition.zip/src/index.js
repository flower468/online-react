import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  constructor(){
    super();
    this.state = {
      power : 3
    }
  }
/* STEP 1
render(){
  if(this.state.power > 5){
    return <h1>Hero is Strong</h1>
  }else{
    return <h1>Hero needs Rest</h1>
  }
}
*/
/* STEP 2 
render(){
  return ( this.state.power > 5 ) && <h1> Hero is Strong </h1> ; 
}
*/

  render(){
      return (this.state.power > 4) ? <h1>Hero is Strong</h1> : <h1>Hero needs Boost</h1>;
  }
}

ReactDOM.render(<MainApp/>, document.getElementById('root')
);
