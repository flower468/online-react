import React, { Component, PureComponent } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
  constructor(){
    super();
    this.state = {  power : 5    }
  }
  setPower = () =>{
    this.setState({
      power : this.state.power
    })
  }
  render(){
    console.log("MainApp rendered");
    return <div>
      <h1> Welcome to your life </h1>
      <h2> Power now is : { this.state.power } </h2>
      <button onClick={ this.setPower }>Set Power</button>
      <FirstComp heropower={ this.state.power }/>
      <SecondComp heropower={ this.state.power }/>
    </div>
  }
}
//-------------------------------------
class FirstComp extends Component{
  render(){
    console.log("FirstComp rendered");
    return <div>
      <h1> FirstComp </h1>
      <h2> Power sent from parent is : { this.props.heropower }</h2>
    </div>
  }
}
//-------------------------------------
class SecondComp extends PureComponent{
  render(){
    console.log("SecondComp rendered");
    return <div>
      <h1> SecondComp </h1>
      <h2> Power sent from parent is : { this.props.heropower }</h2>
    </div>
  }
}
ReactDOM.render(<MainApp/>,
  document.getElementById('root')
);
