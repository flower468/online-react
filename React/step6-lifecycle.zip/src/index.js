import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/*
creation / mounting
      constructor
      getDerivedStateFromProps
      render
      componentDidMount
update
      getDerivedStateFromProps
      shouldComponentUpdate
      render
      getSnapshotBeforeUpdate
      componentDidUpdate

deletion / unmounting
      componentWillUnmount
*/

/*
constructor
getDerivedStateFromProps
render
componentDidMount
*/

class MainApp extends Component{
  constructor(){
    console.log("MainApp's constructor was called");
    super();
    this.state = {

    }
  }

  static getDerivedStateFromProps(){
    console.log("MainApp's getDerivedStateFromProps was called");
    return true
  }

  componentDidMount(){
    console.log("MainApp's componentDidMount was called");
  }


  render(){
    console.log("MainApp's render was called");
    return <div>
      <h1> Welcome to your life </h1>
      <ChildComp></ChildComp>
    </div>
  }
}


class ChildComp extends Component{
  constructor(){
    console.log("ChildComp's constructor was called");
    super();
    this.state = {

    }
  }


   //--------------------------------------------

   componentDidMount(){
     console.log(" ChildComp's componentDidMount  was called ")
   }

   static getDerivedStateFromProps(){
     console.log(" ChildComp's getDerivedStateFromProps  was called ")
     return true
   }

   shouldComponentUpdate(){
     console.log(" ChildComp's  shouldComponentUpdate was called ")
   }

   getSnapshotBeforeUpdate(){
     console.log(" ChildComp's getSnapshotBeforeUpdate  was called ")
   }

   componentDidUpdate(){
     console.log(" ChildComp's componentDidUpdate  was called ")
   }

  //--------------------------------------------
  render(){
    console.log("ChildComp's render was called");
    return <div>
      <h2> Hello from the child component </h2>
    </div>
  }


}



ReactDOM.render(<MainApp/>,
  document.getElementById('root')
);
